Myjlis GITEX YouthX 2026 landing kit

index.html                              the approved landing page (source of truth for layout, colours, animations, buttons)
assets/                                 every image the page uses, plus ruya-2026-logo.png
presentation.html                       the full animated presentation, opened by "View the presentation" in a full screen overlay
GITEX_YouthX_2026_Myjlis_Hackathon.pdf  the PDF behind every "Download PDF" button
gitex-youthx-2026-film.mp4              the 60 second film (new section #film after the hero), poster assets/film-poster.jpg
